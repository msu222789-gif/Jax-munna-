# JAX MUNNA AI PHOTO EDITOR — Complete Client Handover Documentation

This document contains the complete technical, operational, and distribution handover guide for **JAX MUNNA AI PHOTO EDITOR**. It is prepared for the purchasing client to ensure seamless ownership transfer, local compilation, Android APK/AAB builds, and Google Play Store publishing.

---

## 1. Executive Summary & Application Overview

- **App Name**: JAX MUNNA AI PHOTO EDITOR
- **Package Identifier**: `com.jaxmunna.aiphotoeditor`
- **Application Type**: Hybrid Native Android (Capacitor 8) + Progressive Web Application (React 18 + Vite + Tailwind CSS)
- **Target Android SDK**: Android 14 / 15 (API 34 / 36), Backward compatible to Android 7.0+ (API 24+)
- **Core Functionalities**:
  - 100% Face Identity Lock & Facial Geometry Preservation Engine
  - Multilingual Prompt Engine with real-time Hindi / Hinglish translation & synthesis
  - Real-time 4K optical photo synthesizer with studio lighting grades & camera passes
  - Side-by-side Before/After original face comparison & Fullscreen Lightbox Zoom
  - 1-Click Master Prompt Bundler (Master Prompt, Negative Prompt, Parameters, Hindi Translation)
  - Offline-first local storage prompt history management
  - Native Android permissions: Camera (`CAMERA`), Storage/Media (`READ_MEDIA_IMAGES`), Internet (`INTERNET`, `ACCESS_NETWORK_STATE`)

---

## 2. Project File Structure & Inventory

The repository is organized into distinct client-owned source files and native build configurations:

```
├── android/                         # Complete Native Android Studio Project
│   ├── app/
│   │   ├── build.gradle             # Android app build configurations (versionCode, SDK levels)
│   │   ├── src/main/
│   │   │   ├── AndroidManifest.xml  # Native Android manifest, permissions, and activities
│   │   │   ├── assets/public/       # Synchronized production web assets (HTML/JS/CSS)
│   │   │   ├── java/                # Native MainActivity Java code
│   │   │   └── res/                 # Android mipmap icons, drawables, splash screens & strings
│   ├── build.gradle                 # Root Gradle configuration
│   ├── gradlew / gradlew.bat        # Gradle wrapper CLI binaries for building APK/AAB
│   └── variables.gradle             # Android SDK version variables (minSdk, compileSdk, targetSdk)
├── public/                          # Public web assets
│   ├── icons/                       # High-resolution PWA & app icons (192px, 512px, maskable)
│   ├── manifest.json                # Web App Manifest for mobile installation
│   └── sw.js                        # Service Worker caching script
├── src/                             # Application React & TypeScript Source Code
│   ├── components/                  # UI Components
│   │   ├── GenerationProgressModal.tsx # Live generation stage progress, timers, & retry handler
│   │   ├── Header.tsx               # Studio header with branding & status
│   │   ├── HistoryModal.tsx         # Saved prompts & history manager
│   │   ├── InstallBanner.tsx        # Mobile installation promotion banner
│   │   ├── InstallModal.tsx         # Dual-tab installation & Android APK build guide
│   │   ├── MobileBottomNav.tsx      # Mobile optimized bottom navigation
│   │   ├── PhotoUploader.tsx        # Drag & drop / camera photo capture component
│   │   ├── PromptControls.tsx       # AI prompt configuration panel, presets, and Hindi voice input
│   │   └── PromptResultCard.tsx     # 4K image preview, before/after compare, lightbox, copy buttons
│   ├── utils/                       # Core Processing Utilities
│   │   ├── photoRenderer.ts         # 4K client-side canvas studio photo synthesis engine
│   │   ├── promptEngine.ts          # Face Lock prompt compiler & Hindi/Hinglish translation logic
│   │   └── pwa.ts                   # PWA installation event listener hooks
│   ├── App.tsx                      # Root application layout & state orchestrator
│   ├── index.css                    # Tailwind CSS definitions
│   ├── main.tsx                     # React entry point & Capacitor Native plugin bootstrap
│   └── types.ts                     # TypeScript data contracts and interfaces
├── capacitor.config.ts              # Capacitor 8 bridge configuration (App ID, Splash, Status Bar)
├── index.html                       # HTML5 template with viewport & mobile meta tags
├── metadata.json                    # Applet metadata descriptor
├── package.json                     # NPM dependencies & build automation scripts
├── tsconfig.json                    # TypeScript compiler configuration
├── vite.config.ts                   # Vite bundler & Tailwind plugin config
└── HANDOVER.md                      # This handover documentation
```

---

## 3. Environment & Prerequisites

To build and test the Android application on your own development computer, ensure the following software is installed:

1. **Node.js**: Version 18.x or 20.x LTS ([nodejs.org](https://nodejs.org))
2. **Java Development Kit (JDK)**: JDK 17 or JDK 21 (recommended for Android Gradle Plugin 8+)
3. **Android Studio**: Android Studio Ladybug or newer ([developer.android.com/studio](https://developer.android.com/studio))
   - Android SDK Platform 34 or 36
   - Android SDK Build-Tools
   - Android SDK Command-line Tools

---

## 4. How to Build the Android APK (For Direct Installation)

An APK (Android Package) is used for direct testing on physical Android devices without going through Google Play.

### Step 4.1: Install Dependencies & Build Web Assets
From the root of the project directory:
```bash
# 1. Install Node.js packages
npm install

# 2. Compile production web bundle & sync to Android directory
npm run cap:build
```

### Step 4.2: Build Debug APK via Command Line
```bash
# On Linux / macOS:
cd android
./gradlew assembleDebug

# On Windows (PowerShell / CMD):
cd android
gradlew.bat assembleDebug
```
The compiled debug APK will be created at:
`android/app/build/outputs/apk/debug/app-debug.apk`

You can transfer this file to any Android device via USB, Google Drive, or WhatsApp and install it directly (ensure "Install unknown apps" is enabled in phone settings).

---

## 5. How to Build the Android AAB (For Google Play Store Release)

Google Play Store requires the **Android App Bundle (`.aab`)** format for official store distribution.

### Step 5.1: Generate a Production Release Keystore (One-Time Setup)
Create a secure cryptographic signing key on your local machine using Java's `keytool`:

```bash
keytool -genkey -v -keystore jaxmunna-release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias jaxmunna
```
*Store `jaxmunna-release-key.jks` and your password in a secure password manager. Never lose this key, as Google Play requires the same key for future app updates.*

### Step 5.2: Build Signed AAB via Android Studio (Recommended Method)
1. Launch **Android Studio**.
2. Click **Open** and select the `/android` directory of this project.
3. Wait for Gradle sync to finish.
4. From the top menu bar, click: **Build** > **Generate Signed Bundle / APK...**
5. Select **Android App Bundle** and click **Next**.
6. Choose your `jaxmunna-release-key.jks` file, enter your password and alias (`jaxmunna`), and click **Next**.
7. Select **release** build variant and click **Finish**.
8. The release bundle will be generated at:
   `android/app/release/app-release.aab`

---

## 6. External Services, APIs & Accounts Required

| Service / Account | Purpose | Required For | Cost / Plan |
| :--- | :--- | :--- | :--- |
| **Google Play Developer Account** | Official publishing on Google Play Store | Android Distribution | $25 one-time registration fee to Google |
| **Domain & Web Hosting (Optional)** | Hosting the web version / live PWA preview (e.g., Cloud Run, Vercel, Netlify) | Web / PWA version | Free tier available on most platforms |
| **Gemini AI API (Optional)** | Server-side AI prompt generation / image enhancement | Optional Server Features | Pay-as-you-go via Google Cloud / AI Studio |

---

## 7. Credentials & Security Architecture

### Zero Hard-Coded Credentials in Android Client
- The Android client code contains **NO secret API keys or private credentials**.
- Client-side code is fully safeguarded against decompilation/reverse-engineering vulnerabilities.
- If you integrate custom backend server-side AI endpoints, keep the API keys exclusively on your backend server (`process.env.GEMINI_API_KEY`) and communicate with the Android client over HTTPS.

### Safe Transfer Checklist
When transferring accounts or infrastructure:
1. **Never send passwords or signing keys over unencrypted email or public chat.**
2. Invite the client's email as an **Owner** / **Admin** on the Google Play Console or Cloud project.
3. Provide the client with their unique `.jks` release keystore and alias credentials through a secure vault.

---

## 8. Google Play Store Publishing Checklist

To publish under the client's Google Play Developer account:

1. **Google Play Console Setup**:
   - Log into [Google Play Console](https://play.google.com/console).
   - Click **Create App**, enter App name: **JAX MUNNA AI PHOTO EDITOR**, Default language: English, App type: App, Free/Paid: Free (or Paid).
2. **Store Listing Details**:
   - **Short Description** (up to 80 chars): *4K AI Photo Editor & Prompt Studio with 100% Face Identity Preservation.*
   - **Full Description**: Detail features including Face Lock geometry, Hindi/Hinglish translation, 4K camera lighting synthesis, and Before/After preview.
   - **App Icon**: 512x512 PNG (provided in `/public/icons/icon-512.svg` / exportable as PNG).
   - **Feature Graphic**: 1024x500 PNG banner.
   - **Screenshots**: At least 2 phone screenshots (take direct captures running the app).
3. **App Content & Policies**:
   - **Privacy Policy**: Provide a URL to your privacy policy describing camera/storage usage for local photo editing.
   - **Data Safety**: Declare that photos are processed locally on the user's device for photo synthesis and prompt engineering.
   - **Target Audience**: 13+ (or General).
4. **Upload Release**:
   - Navigate to **Production** > **Create new release**.
   - Upload `android/app/release/app-release.aab`.
   - Enter Release Name (e.g., `1.0.0 (1)`) and Release Notes.
   - Submit for Google Review.

---

## 9. Status & Verification Summary

###  Completed & Verified in Repository:
- [x] Complete React 18 + TypeScript + Tailwind CSS source code.
- [x] Native Capacitor 8 Android platform configured in `/android`.
- [x] App Name configured as `"JAX MUNNA AI PHOTO EDITOR"` across manifest, strings, and web config.
- [x] Package ID configured as `com.jaxmunna.aiphotoeditor`.
- [x] Camera and Storage media permissions added to `AndroidManifest.xml`.
- [x] Complete photo rendering engine with 100% Face Lock, prompt bundler, and Before/After compare.
- [x] Build scripts verified (`npm run build` and `npm run cap:sync` pass with 0 errors).
- [x] `.gitignore` updated to protect release keystores and Android build artifacts.

### 📋 Required Actions Outside This Repository:
1. **Run Gradle Build**: Run `./gradlew assembleDebug` (for APK) or `./gradlew bundleRelease` (for AAB) on your local machine with JDK/Android Studio installed.
2. **Create Release Keystore**: Generate the client's `.jks` file using `keytool` as documented in Section 5.
3. **Google Play Console Account**: Register the client's developer account and create the store listing.
