import React, { useState, useEffect, useRef } from 'react';
import { Header } from './components/Header';
import { InstallBanner } from './components/InstallBanner';
import { InstallModal } from './components/InstallModal';
import { PhotoUploader } from './components/PhotoUploader';
import { PromptControls } from './components/PromptControls';
import { PromptResultCard } from './components/PromptResultCard';
import { HistoryModal } from './components/HistoryModal';
import { MobileBottomNav } from './components/MobileBottomNav';
import { GenerationProgressModal } from './components/GenerationProgressModal';
import { PromptOptions, GeneratedPromptData, PromptHistoryItem } from './types';
import { generateSmartPrompt } from './utils/promptEngine';
import { renderSynthesizedPhoto } from './utils/photoRenderer';
import { usePwaInstall } from './utils/pwa';
import { ShieldCheck, Sparkles, Smartphone, CheckCircle2 } from 'lucide-react';

const DEFAULT_OPTIONS: PromptOptions = {
  targetPlatform: 'midjourney',
  aspectRatio: '9:16',
  quality: '4k',
  lighting: 'golden_hour',
  background: 'luxury_car',
  clothes: 'black_suit',
  hairstyle: 'keep_original',
  pose: 'confident_portrait',
  keepOriginalFace: true,
  colorEnhance: true,
  hdrLighting: true
};

const STORAGE_KEY_HISTORY = 'jax_munna_history_v1';
const STORAGE_KEY_OPTIONS = 'jax_munna_options_v1';

export default function App() {
  const pwa = usePwaInstall();
  const [isInstallModalOpen, setIsInstallModalOpen] = useState(false);
  const [isBannerDismissed, setIsBannerDismissed] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [activeMobileTab, setActiveMobileTab] = useState<'editor' | 'result' | 'history'>('editor');

  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [userRequest, setUserRequest] = useState(
    'bhai black coat pehna do and royal car piche khadi kardo, chehra 100% same rakhna'
  );
  const [options, setOptions] = useState<PromptOptions>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_OPTIONS);
      return saved ? JSON.parse(saved) : DEFAULT_OPTIONS;
    } catch {
      return DEFAULT_OPTIONS;
    }
  });

  const [currentResult, setCurrentResult] = useState<GeneratedPromptData | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isGenerationModalOpen, setIsGenerationModalOpen] = useState(false);
  const [generationProgress, setGenerationProgress] = useState(0);
  const [generationStage, setGenerationStage] = useState('');
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [estimatedRemainingSeconds, setEstimatedRemainingSeconds] = useState(16);
  const [isStillProcessing, setIsStillProcessing] = useState(false);
  const [generationError, setGenerationError] = useState<string | null>(null);
  const cancelGenerationRef = useRef(false);

  const [history, setHistory] = useState<PromptHistoryItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_HISTORY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Save options changes to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_OPTIONS, JSON.stringify(options));
    } catch (e) {
      console.warn('LocalStorage save failed', e);
    }
  }, [options]);

  // Save history changes to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_HISTORY, JSON.stringify(history));
    } catch (e) {
      console.warn('LocalStorage save failed', e);
    }
  }, [history]);

  // Handle Photo Selection with Face Scan effect
  const handlePhotoSelected = (dataUrl: string | null) => {
    setPhotoPreview(dataUrl);
    if (dataUrl) {
      setIsScanning(true);
      setTimeout(() => {
        setIsScanning(false);
      }, 900);
    }
  };

  // Safe Cancel Action
  const handleCancelGeneration = () => {
    cancelGenerationRef.current = true;
    setIsGenerating(false);
    setIsGenerationModalOpen(false);
    setGenerationError(null);
  };

  // Generate Prompt & Photo Action with live progress and countdown
  const handleGenerate = async () => {
    if (isGenerating) return; // Prevent duplicate requests

    cancelGenerationRef.current = false;
    setIsGenerating(true);
    setIsGenerationModalOpen(true);
    setGenerationError(null);
    setGenerationProgress(8);
    setGenerationStage('Initializing Neural Face Engine...');
    setElapsedSeconds(0);
    setEstimatedRemainingSeconds(15);
    setIsStillProcessing(false);

    const startTime = Date.now();
    const timerInterval = setInterval(() => {
      if (cancelGenerationRef.current) {
        clearInterval(timerInterval);
        return;
      }
      const elapsed = Math.floor((Date.now() - startTime) / 1000);
      setElapsedSeconds(elapsed);
      const remaining = Math.max(1, 15 - elapsed);
      setEstimatedRemainingSeconds(remaining);

      if (elapsed >= 12) {
        setIsStillProcessing(true);
      }
    }, 400);

    try {
      // 1. Generate smart prompt metadata bundle
      const promptResult = generateSmartPrompt(userRequest, options, photoPreview || undefined);

      if (cancelGenerationRef.current) {
        clearInterval(timerInterval);
        return;
      }

      // 2. Synthesize photorealistic 4K studio rendering
      const photoUrl = await renderSynthesizedPhoto(
        photoPreview || undefined,
        options,
        (pct, stageName) => {
          if (!cancelGenerationRef.current) {
            setGenerationProgress(pct);
            setGenerationStage(stageName);
          }
        }
      );

      if (cancelGenerationRef.current) {
        clearInterval(timerInterval);
        return;
      }

      clearInterval(timerInterval);
      setGenerationProgress(100);
      setGenerationStage('Render Complete! Opening Studio Output...');

      const finalResult: GeneratedPromptData = {
        ...promptResult,
        generatedPhotoUrl: photoUrl
      };

      setCurrentResult(finalResult);
      setHistory((prev) => [finalResult, ...prev.filter((i) => i.id !== finalResult.id).slice(0, 29)]);

      // Close modal and smoothly transition to result
      setTimeout(() => {
        setIsGenerating(false);
        setIsGenerationModalOpen(false);
        setActiveMobileTab('result');

        // Scroll to result on desktop
        if (window.innerWidth >= 640) {
          const resultCard = document.getElementById('generated-prompt-result-card');
          if (resultCard) {
            resultCard.scrollIntoView({ behavior: 'smooth' });
          } else {
            window.scrollTo({ top: 250, behavior: 'smooth' });
          }
        }
      }, 450);
    } catch (err: any) {
      clearInterval(timerInterval);
      console.error('Generation Error:', err);
      setIsGenerating(false);
      setGenerationError(err?.message || 'Failed to synthesize photo. Please check your image format and try again.');
    }
  };

  // Load Prompt from History
  const handleSelectFromHistory = (item: GeneratedPromptData) => {
    setCurrentResult(item);
    setUserRequest(item.userRequest);
    setOptions(item.options);
    if (item.referencePhotoPreview) {
      setPhotoPreview(item.referencePhotoPreview);
    }
    setActiveMobileTab('result');
  };

  const handleClearHistory = () => {
    setHistory([]);
  };

  const handleDeleteHistoryItem = (id: string) => {
    setHistory((prev) => prev.filter((i) => i.id !== id));
  };

  return (
    <div className="min-h-screen bg-[#08090d] text-slate-100 pb-20 sm:pb-12 flex flex-col font-sans">
      {/* App Header */}
      <Header
        onOpenHistory={() => setIsHistoryOpen(true)}
        historyCount={history.length}
        onOpenInstallModal={() => setIsInstallModalOpen(true)}
        isInstallable={pwa.isInstallable}
        isInstalled={pwa.isInstalled}
      />

      {/* PWA Install Banner (Top sticky for Android/iOS users) */}
      <InstallBanner
        isInstallable={pwa.isInstallable}
        isInstalled={pwa.isInstalled}
        onOpenInstallModal={() => setIsInstallModalOpen(true)}
        onDismiss={() => setIsBannerDismissed(true)}
        isDismissed={isBannerDismissed}
      />

      {/* Main Studio Workspace */}
      <main className="flex-1 max-w-7xl mx-auto w-full px-3 sm:px-6 py-4 sm:py-6">
        {/* Hero Badge Banner */}
        <div className="mb-4 p-3 sm:p-4 rounded-2xl bg-gradient-to-r from-amber-500/10 via-amber-600/5 to-slate-900/40 border border-amber-500/30 flex flex-wrap items-center justify-between gap-3 shadow-lg">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs sm:text-sm font-bold text-slate-100">
                  Strict 100% Face Identity Preservation Engine
                </span>
                <span className="hidden sm:inline text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                  InstantID 0.95
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                Guarantees zero facial distortion while swapping clothes, background & lighting in 4K
              </p>
            </div>
          </div>

          {!pwa.isInstalled && (
            <button
              onClick={() => setIsInstallModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/30 text-amber-300 text-xs font-semibold transition-all"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>PWA Mobile App</span>
            </button>
          )}
        </div>

        {/* Mobile Tab Switching Controls (visible only on small screens) */}
        <div className="sm:hidden flex border-b border-slate-800 mb-3 gap-1">
          <button
            onClick={() => setActiveMobileTab('editor')}
            className={`flex-1 py-2 text-xs font-bold text-center border-b-2 transition-all ${
              activeMobileTab === 'editor'
                ? 'border-amber-400 text-amber-300 bg-amber-500/10'
                : 'border-transparent text-slate-400'
            }`}
          >
            Studio Editor
          </button>
          <button
            onClick={() => setActiveMobileTab('result')}
            className={`flex-1 py-2 text-xs font-bold text-center border-b-2 transition-all relative ${
              activeMobileTab === 'result'
                ? 'border-amber-400 text-amber-300 bg-amber-500/10'
                : 'border-transparent text-slate-400'
            }`}
          >
            4K Output {currentResult && <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block ml-1"></span>}
          </button>
        </div>

        {/* Main Grid: Left Editor & Right Result Output */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 sm:gap-6">
          {/* Left Column: Photo Uploader & Controls */}
          <div
            className={`lg:col-span-7 space-y-4 ${
              activeMobileTab === 'result' ? 'hidden sm:block' : 'block'
            }`}
          >
            {/* Step 1: Photo Uploader */}
            <PhotoUploader
              photoPreview={photoPreview}
              onPhotoSelected={handlePhotoSelected}
              isScanning={isScanning}
            />

            {/* Step 2 & 3: Prompt Controls */}
            <PromptControls
              userRequest={userRequest}
              setUserRequest={setUserRequest}
              options={options}
              setOptions={setOptions}
              onGenerate={handleGenerate}
              isGenerating={isGenerating}
              hasPhoto={!!photoPreview}
            />
          </div>

          {/* Right Column: Output Result Card */}
          <div
            className={`lg:col-span-5 space-y-4 ${
              activeMobileTab === 'editor' ? 'hidden sm:block' : 'block'
            }`}
          >
            {currentResult ? (
              <PromptResultCard
                data={currentResult}
                onReusePrompt={handleSelectFromHistory}
              />
            ) : (
              <div className="bg-[#0e111a] border border-slate-800 rounded-2xl p-6 text-center space-y-3">
                <div className="w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center mx-auto text-amber-400">
                  <Sparkles className="w-7 h-7" />
                </div>
                <h3 className="text-base font-bold text-slate-100">Ready to Generate 4K AI Prompt</h3>
                <p className="text-xs text-slate-400 max-w-sm mx-auto">
                  Upload your face photo, select your dream clothes/background/lighting, and tap <strong>Generate</strong> for 100% Face Locked prompts.
                </p>
                <button
                  onClick={handleGenerate}
                  className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-bold text-xs shadow-lg shadow-amber-500/20 transition-all"
                >
                  Generate First Prompt
                </button>
              </div>
            )}

            {/* PWA Benefits Card */}
            <div className="p-4 bg-slate-900/60 border border-slate-800/80 rounded-2xl space-y-2 text-xs text-slate-300">
              <div className="flex items-center gap-2 font-bold text-amber-300">
                <Smartphone className="w-4 h-4 text-amber-400" />
                <span>PWA Installation Benefits:</span>
              </div>
              <ul className="space-y-1.5 text-slate-400 text-[11px] list-disc list-inside">
                <li>Instant 1-tap launch from Android / iPhone Home Screen</li>
                <li>Zero address bar or browser controls for full-screen workflow</li>
                <li>Offline prompt history storage & fast local processing</li>
              </ul>
              {!pwa.isInstalled && (
                <button
                  onClick={() => setIsInstallModalOpen(true)}
                  className="w-full mt-2 py-2 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 font-semibold text-xs border border-slate-700 text-center transition-colors"
                >
                  Tap to Install App on Mobile
                </button>
              )}
            </div>
          </div>
        </div>
      </main>

      {/* PWA Mobile Bottom Navigation */}
      <MobileBottomNav
        activeTab={activeMobileTab}
        setActiveTab={(tab) => {
          if (tab === 'history') {
            setIsHistoryOpen(true);
          } else {
            setActiveMobileTab(tab);
          }
        }}
        hasResult={!!currentResult}
        historyCount={history.length}
        onOpenInstallModal={() => setIsInstallModalOpen(true)}
        isInstalled={pwa.isInstalled}
      />

      {/* Install Modal */}
      <InstallModal
        isOpen={isInstallModalOpen}
        onClose={() => setIsInstallModalOpen(false)}
        onTriggerInstall={pwa.triggerInstall}
        isInstallable={pwa.isInstallable}
        isInstalled={pwa.isInstalled}
        isIOS={pwa.isIOS}
        isAndroid={pwa.isAndroid}
      />

      {/* History Modal */}
      <HistoryModal
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        history={history}
        onSelectPrompt={handleSelectFromHistory}
        onClearHistory={handleClearHistory}
        onDeleteItem={handleDeleteHistoryItem}
      />

      {/* Generation Progress & Error Retry Modal */}
      <GenerationProgressModal
        isOpen={isGenerationModalOpen}
        progressPercent={generationProgress}
        currentStage={generationStage}
        elapsedSeconds={elapsedSeconds}
        estimatedRemainingSeconds={estimatedRemainingSeconds}
        isStillProcessing={isStillProcessing}
        errorMessage={generationError}
        onRetry={handleGenerate}
        onCancel={handleCancelGeneration}
        hasPhoto={!!photoPreview}
      />
    </div>
  );
}
