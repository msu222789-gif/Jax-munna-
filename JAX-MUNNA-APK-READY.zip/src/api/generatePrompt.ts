import { GoogleGenAI } from '@google/genai';
import { GeneratedPromptData, PromptOptions } from '../types';
import { generateSmartPrompt } from '../utils/promptEngine';

interface GeneratePromptPayload {
  userRequest?: string;
  options?: PromptOptions;
  photoPreview?: string;
}

let aiClient: GoogleGenAI | null = null;

function getAiClient(): GoogleGenAI | null {
  if (!aiClient && process.env.GEMINI_API_KEY) {
    aiClient = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

export async function generateGeminiPrompt(
  payload: GeneratePromptPayload
): Promise<GeneratedPromptData> {
  const userRequest = payload.userRequest || '';
  const options: PromptOptions = payload.options || {
    targetPlatform: 'midjourney',
    aspectRatio: '9:16',
    quality: '4k',
    lighting: 'golden_hour',
    background: 'luxury_car',
    clothes: 'black_suit',
    hairstyle: 'keep_original',
    pose: 'confident_portrait',
    keepOriginalFace: true,
    colorEnhance: true,
    hdrLighting: true,
  };

  // Base prompt generated from local rule engine
  const baseResult = generateSmartPrompt(userRequest, options, payload.photoPreview);

  const ai = getAiClient();
  if (!ai) {
    return baseResult;
  }

  try {
    const systemInstruction = `You are JAX MUNNA, an expert AI prompt engineer specializing in hyper-photorealistic portrait photography and text-to-image prompts (Midjourney v6.1, Flux.1, SDXL, DALL-E 3).
Your task is to take a user's natural language request (often in Hindi/Hinglish/English) along with their selected photography options, and enhance the prompt with strict 100% facial identity preservation keywords, ultra-sharp 4K optical camera specifications, realistic texture details, and accurate lighting.
Return a valid JSON object matching the exact structure requested.`;

    const promptText = `User Request: "${userRequest}"
Target Platform: ${options.targetPlatform}
Aspect Ratio: ${options.aspectRatio}
Quality Preset: ${options.quality}
Lighting: ${options.lighting}
Background: ${options.background}
Outfit: ${options.clothes}
Keep Face 100% Locked: ${options.keepOriginalFace ? 'YES' : 'NO'}

Generate an enhanced master prompt and a clear explanation in Hindi/Hinglish.
Respond with JSON only:
{
  "masterPrompt": "string (the complete optimized photorealistic prompt)",
  "negativePrompt": "string (anti-distortion and face preservation tokens)",
  "hindiExplanation": "string (friendly explanation in Hindi/Hinglish of what was styled while keeping the face intact)"
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: promptText,
      config: {
        systemInstruction,
        responseMimeType: 'application/json',
      },
    });

    const responseText = response.text;
    if (responseText) {
      const parsed = JSON.parse(responseText);
      return {
        ...baseResult,
        masterPrompt: parsed.masterPrompt || baseResult.masterPrompt,
        negativePrompt: parsed.negativePrompt || baseResult.negativePrompt,
        hindiExplanation: parsed.hindiExplanation || baseResult.hindiExplanation,
      };
    }
  } catch (error) {
    console.warn('Gemini API prompt generation fallback to rule engine:', error);
  }

  return baseResult;
}
