import { GeneratedPromptData, PromptOptions } from '../types';

export function generateSmartPrompt(
  userRequest: string,
  options: PromptOptions,
  photoPreview?: string
): GeneratedPromptData {
  const req = (userRequest || '').trim();
  const lowerReq = req.toLowerCase();

  // Face preservation tokens
  const faceLockToken = options.keepOriginalFace
    ? '[EXACT SAME PERSON AS REFERENCE PHOTO, 100% STRICT FACIAL IDENTITY PRESERVATION, IDENTICAL FACIAL STRUCTURE, EXACT NOSE, LIPS, EYES, AND SKIN TONE, UNALTERED HEAD SHAPE, NO MORPHING]'
    : '[High aesthetic natural facial features]';

  const instantIdWeight = options.keepOriginalFace
    ? 'InstantID / IP-Adapter weight: 0.95 | Face Identity: 100% Locked | Facial Landmark Anchor: ACTIVE'
    : 'Face Identity: Creative Variation Mode';

  // Clothing & Outfit synthesis
  let outfitDesc = '';
  if (lowerReq.includes('black coat') || lowerReq.includes('black suit') || options.clothes === 'black_suit') {
    outfitDesc = 'dressed in a tailored bespoke matte-black Italian tuxedo with satin lapels, crisp silk white shirt, and gold cufflinks';
  } else if (lowerReq.includes('sherwani') || lowerReq.includes('kurta') || options.clothes === 'royal_sherwani') {
    outfitDesc = 'dressed in a regal ivory raw-silk designer Sherwani with intricate gold Zari embroidery, emerald brooch, and royal shawl';
  } else if (lowerReq.includes('leather') || options.clothes === 'casual_leather') {
    outfitDesc = 'wearing a premium distressed black cafe-racer leather jacket over a fitted dark charcoal crewneck';
  } else if (lowerReq.includes('hoodie') || lowerReq.includes('streetwear') || options.clothes === 'streetwear_hoodie') {
    outfitDesc = 'wearing an oversized luxury heavyweight street-couture hoodie with minimal typography';
  } else if (options.clothes === 'old_money_linen') {
    outfitDesc = 'wearing an old-money quiet luxury tailored linen blazer with cream polo';
  } else if (options.clothes === 'cyber_tactical') {
    outfitDesc = 'wearing futuristic matte-black techwear jacket with subtle neon accents';
  } else {
    outfitDesc = 'wearing the same identical clothing styling from the reference photo, rendered in ultra-high fabric texture';
  }

  // Background & Scene synthesis
  let sceneDesc = '';
  if (lowerReq.includes('car') || lowerReq.includes('gaadi') || options.background === 'luxury_car') {
    sceneDesc = 'standing in front of a sleek gloss-black Rolls-Royce Phantom and luxury supercar parked on a wet cobblestone driveway outside a Beverly Hills mansion';
  } else if (lowerReq.includes('cyber') || lowerReq.includes('neon') || options.background === 'cyberpunk_city') {
    sceneDesc = 'standing in a bustling high-tech neo-Tokyo street with vibrant holographic neon reflections on wet asphalt';
  } else if (lowerReq.includes('palace') || lowerReq.includes('mahal') || options.background === 'royal_palace') {
    sceneDesc = 'posing in an opulent royal palace courtyard with carved marble arches, glowing warm chandeliers, and fountain reflections';
  } else if (lowerReq.includes('studio') || options.background === 'minimal_studio') {
    sceneDesc = 'in a clean architectural studio against a seamless gradient cyclorama wall with soft edge lighting';
  } else if (lowerReq.includes('mountain') || lowerReq.includes('pahar') || options.background === 'nature_mountains') {
    sceneDesc = 'surrounded by scenic snow-capped alpine mountains at sunrise with misty golden valley';
  } else if (options.background === 'penthouse_balcony') {
    sceneDesc = 'standing on a luxury penthouse balcony overlooking a panoramic illuminated Dubai skyline at dusk';
  } else if (options.background === 'blur_original' || lowerReq.includes('blur')) {
    sceneDesc = 'in a naturally blurred background with creamy f/1.4 optical bokeh depth of field, keeping full focus on the subject';
  } else {
    sceneDesc = 'in an atmospheric cinematic setting that complements the subject with natural photographic depth';
  }

  // Lighting synthesis
  let lightingDesc = '';
  if (options.lighting === 'golden_hour') {
    lightingDesc = 'warm golden hour sunset backlighting with soft rim light highlighting hair details and amber lens flare';
  } else if (options.lighting === 'diffused_softbox') {
    lightingDesc = 'high-end commercial studio softbox lighting, perfectly balanced key and fill lights, velvety smooth shadow roll-off';
  } else if (options.lighting === 'cyber_neon') {
    lightingDesc = 'dual tone cinematic lighting with electric cyan rim light and vivid magenta fill light';
  } else if (options.lighting === 'rembrandt') {
    lightingDesc = 'dramatic Rembrandt studio portrait lighting with triangular highlight on cheek, deep moody shadows';
  } else if (options.lighting === 'sunset_rim') {
    lightingDesc = 'dramatic twilight backlight with warm copper highlights framing the subject silhouette';
  } else {
    lightingDesc = 'cinematic atmospheric lighting with rich color grading and high dynamic range';
  }

  // Camera & Rendering specs
  let cameraSpecs = '';
  if (options.quality === 'iphone') {
    cameraSpecs = 'Shot on iPhone 16 Pro Max Portrait Mode, 77mm focal length, f/1.8 aperture, Apple Photonic Engine, natural skin texture, realistic HDR tone mapping';
  } else if (options.quality === 'portra_400') {
    cameraSpecs = 'Shot on 35mm film, Kodak Portra 400 aesthetic, organic film grain, Leica M11 with Summilux-M 50mm f/1.4 lens, warm nostalgic color grade';
  } else if (options.quality === 'hasselblad') {
    cameraSpecs = 'Shot on Hasselblad H6D-100c medium format camera, HC 100mm f/2.2 lens, 100 megapixels ultra detail, micro-contrast, accurate skin pores and iris reflections';
  } else if (options.quality === 'cinematic_8k') {
    cameraSpecs = 'Shot on ARRI Alexa Mini LF with Cooke Anamorphic /i Full Frame Plus lens, anamorphic horizontal bokeh, 8k RED raw film capture';
  } else {
    cameraSpecs = 'Masterpiece commercial portrait, Sony A7R V with G Master 85mm f/1.4 lens, razor-sharp focus on eyes, ultra-realistic skin texture, 8K UHD, photorealistic';
  }

  // Target platform parameters
  let platformParams = '';
  if (options.targetPlatform === 'midjourney') {
    platformParams = `--ar ${options.aspectRatio.replace(':', ':')} --style raw --v 6.1 --q 2 --s 750`;
  } else if (options.targetPlatform === 'flux') {
    platformParams = `[Flux.1 dev | steps: 35 | guidance: 3.8 | sampler: ddim | aspect: ${options.aspectRatio}]`;
  } else if (options.targetPlatform === 'sdxl') {
    platformParams = `[SDXL 1.0 + InstantID LoRA 0.95 | CFG: 7.0 | Sampler: DPM++ 2M Karras | Steps: 40]`;
  } else {
    platformParams = `[DALL-E 3 | Style: Vivid Photorealism | Quality: HD | Aspect: ${options.aspectRatio}]`;
  }

  // Compile Master Prompt
  const masterPrompt = `A cinematic ultra-photorealistic portrait of the subject ${faceLockToken} ${outfitDesc}, ${sceneDesc}. ${lightingDesc}. ${cameraSpecs}, hyper-detailed hair strands, natural skin pores, realistic eye moisture and corneal reflections, award-winning editorial composition ${platformParams}`;

  // Negative Prompt
  const negativePrompt =
    'face morphing, altered face structure, different person, duplicate eyes, fake smile, plastic skin, overly airbrushed, cartoon, 3d render, illustration, blurry face, extra fingers, mutated hands, bad anatomy, deformed limbs, oversaturated, low quality, artifact, watermark, signature';

  // Hindi / Hinglish Explanation
  const hindiExplanation = options.keepOriginalFace
    ? `Aapki request (${req || 'Custom Studio Look'}) ke hisaab se 100% Face Identity Lock tokens apply kiye gaye hain. Chehre ke features, eye shape, nose structure, aur skin tone ko reference photo ke saath 1:1 anchor kiya gaya hai, jabki outfit (${options.clothes.replace('_', ' ')}), lighting (${options.lighting.replace('_', ' ')}), aur background scene ko high-end 4K photo quality me upgrade kiya gaya hai.`
    : `Creative aesthetic mode me prompt banaya gaya hai jisme stylish styling aur photorealistic lighting setup shamil hai.`;

  // Highlights tags
  const highlights: string[] = [
    options.targetPlatform.toUpperCase(),
    options.aspectRatio,
    options.quality.toUpperCase(),
    options.lighting.replace('_', ' ').toUpperCase(),
    options.keepOriginalFace ? '100% FACE LOCKED' : 'CREATIVE MODE',
    options.clothes.replace('_', ' ').toUpperCase()
  ];

  return {
    id: 'jm_' + Date.now().toString(36) + Math.random().toString(36).substring(2, 6),
    createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    masterPrompt,
    negativePrompt,
    facePreservationTokens: instantIdWeight,
    hindiExplanation,
    platformParameters: platformParams,
    promptHighlights: highlights,
    options,
    userRequest: req,
    hasReferencePhoto: !!photoPreview,
    referencePhotoPreview: photoPreview
  };
}
