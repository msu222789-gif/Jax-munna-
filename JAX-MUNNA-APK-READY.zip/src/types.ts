export type TargetPlatform = 'midjourney' | 'flux' | 'sdxl' | 'dalle3';

export type AspectRatio = '9:16' | '1:1' | '4:5' | '16:9' | '3:4';

export type QualityPreset = '4k' | 'iphone' | 'portra_400' | 'hasselblad' | 'cinematic_8k';

export type LightingPreset =
  | 'golden_hour'
  | 'diffused_softbox'
  | 'cyber_neon'
  | 'rembrandt'
  | 'sunset_rim'
  | 'cinematic_moody';

export type BackgroundPreset =
  | 'keep_original'
  | 'blur_original'
  | 'luxury_car'
  | 'cyberpunk_city'
  | 'royal_palace'
  | 'minimal_studio'
  | 'nature_mountains'
  | 'penthouse_balcony';

export type ClothesPreset =
  | 'keep_original'
  | 'black_suit'
  | 'royal_sherwani'
  | 'casual_leather'
  | 'streetwear_hoodie'
  | 'old_money_linen'
  | 'cyber_tactical';

export interface PromptOptions {
  targetPlatform: TargetPlatform;
  aspectRatio: AspectRatio;
  quality: QualityPreset;
  lighting: LightingPreset;
  background: BackgroundPreset;
  clothes: ClothesPreset;
  hairstyle: string;
  pose: string;
  keepOriginalFace: boolean;
  colorEnhance: boolean;
  hdrLighting: boolean;
}

export interface GeneratedPromptData {
  id: string;
  createdAt: string;
  masterPrompt: string;
  negativePrompt: string;
  facePreservationTokens: string;
  hindiExplanation: string;
  platformParameters: string;
  promptHighlights: string[];
  options: PromptOptions;
  userRequest: string;
  hasReferencePhoto: boolean;
  referencePhotoPreview?: string;
  generatedPhotoUrl?: string;
}

export interface PromptHistoryItem extends GeneratedPromptData {
  favorite?: boolean;
}
