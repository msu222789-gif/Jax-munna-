import React from 'react';
import { Camera, Sparkles, History, Smartphone, ShieldCheck } from 'lucide-react';

interface MobileBottomNavProps {
  activeTab: 'editor' | 'result' | 'history';
  setActiveTab: (tab: 'editor' | 'result' | 'history') => void;
  hasResult: boolean;
  historyCount: number;
  onOpenInstallModal: () => void;
  isInstalled: boolean;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  activeTab,
  setActiveTab,
  hasResult,
  historyCount,
  onOpenInstallModal,
  isInstalled
}) => {
  return (
    <div className="sm:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#0a0c12]/95 backdrop-blur-lg border-t border-amber-500/20 px-2 py-1.5 flex items-center justify-around">
      {/* Editor Tab */}
      <button
        onClick={() => setActiveTab('editor')}
        className={`flex flex-col items-center gap-0.5 p-1.5 rounded-lg text-[10px] font-semibold transition-all ${
          activeTab === 'editor' ? 'text-amber-400 bg-amber-500/10' : 'text-slate-400 hover:text-slate-200'
        }`}
      >
        <Camera className="w-4 h-4" />
        <span>Photo Studio</span>
      </button>

      {/* Result Tab */}
      <button
        onClick={() => setActiveTab('result')}
        className={`relative flex flex-col items-center gap-0.5 p-1.5 rounded-lg text-[10px] font-semibold transition-all ${
          activeTab === 'result' ? 'text-amber-400 bg-amber-500/10' : 'text-slate-400 hover:text-slate-200'
        }`}
      >
        <Sparkles className="w-4 h-4" />
        <span>4K Prompt</span>
        {hasResult && (
          <span className="absolute top-1 right-2 w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
        )}
      </button>

      {/* History Tab */}
      <button
        onClick={() => setActiveTab('history')}
        className={`relative flex flex-col items-center gap-0.5 p-1.5 rounded-lg text-[10px] font-semibold transition-all ${
          activeTab === 'history' ? 'text-amber-400 bg-amber-500/10' : 'text-slate-400 hover:text-slate-200'
        }`}
      >
        <History className="w-4 h-4" />
        <span>History</span>
        {historyCount > 0 && (
          <span className="absolute -top-0.5 right-1 px-1 rounded-full bg-amber-500 text-black text-[9px] font-bold">
            {historyCount}
          </span>
        )}
      </button>

      {/* Install App Tab */}
      {!isInstalled && (
        <button
          onClick={onOpenInstallModal}
          className="flex flex-col items-center gap-0.5 p-1.5 rounded-lg text-[10px] font-bold text-amber-300 bg-amber-500/15 border border-amber-500/30"
        >
          <Smartphone className="w-4 h-4 text-amber-400 animate-bounce" />
          <span>Install</span>
        </button>
      )}
    </div>
  );
};
