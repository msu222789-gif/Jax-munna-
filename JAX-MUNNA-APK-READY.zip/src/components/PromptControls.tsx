import React from 'react';
import {
  Sparkles,
  Shield,
  Layers,
  Sun,
  Maximize2,
  Sliders,
  Check,
  Zap,
  Shirt,
  Image as ImageIcon
} from 'lucide-react';
import {
  PromptOptions,
  TargetPlatform,
  AspectRatio,
  QualityPreset,
  LightingPreset,
  BackgroundPreset,
  ClothesPreset
} from '../types';

interface PromptControlsProps {
  userRequest: string;
  setUserRequest: (val: string) => void;
  options: PromptOptions;
  setOptions: React.Dispatch<React.SetStateAction<PromptOptions>>;
  onGenerate: () => void;
  isGenerating: boolean;
  hasPhoto: boolean;
}

const HINGLISH_SUGGESTIONS = [
  '🤵 Black tuxedo pehna do and royal car piche khadi kardo, chehra 100% same rakhna',
  '👑 Royal raw-silk designer Sherwani with palace courtyard background',
  '📸 iPhone 16 Pro portrait bokeh look, keep original clothes & natural lighting',
  '🏎️ Luxury supercar photoshoot outside Beverly Hills mansion with golden hour',
  '🏔️ Snow-capped mountain peak at sunrise with cinematic warm jacket',
  '🌆 Cyberpunk neon street with glowing reflections and leather jacket'
];

export const PromptControls: React.FC<PromptControlsProps> = ({
  userRequest,
  setUserRequest,
  options,
  setOptions,
  onGenerate,
  isGenerating,
  hasPhoto
}) => {
  const updateOption = <K extends keyof PromptOptions>(key: K, value: PromptOptions[K]) => {
    setOptions((prev) => ({ ...prev, [key]: value }));
  };

  return (
    <div className="space-y-4">
      {/* Step 2: Natural Language Hindi / Hinglish Request Input */}
      <div className="bg-[#0e111a] border border-amber-500/20 rounded-2xl p-4 sm:p-5 shadow-xl shadow-black/40">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-amber-500/15 border border-amber-500/30 text-amber-400">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-bold text-slate-100">
                2. Describe Your Edit in Hindi / Hinglish / English
              </h2>
              <p className="text-[11px] text-slate-400">
                Apni bhasha me likhein — AI automatically 4K photorealistic prompt me convert karega
              </p>
            </div>
          </div>
        </div>

        <div className="relative mt-2">
          <textarea
            value={userRequest}
            onChange={(e) => setUserRequest(e.target.value)}
            placeholder="e.g. Bhai black coat pehna do and royal Rolls Royce piche khadi kardo, chehra 100% same rakhna..."
            rows={3}
            className="w-full bg-slate-900/90 border border-slate-700/80 focus:border-amber-400 focus:ring-1 focus:ring-amber-400 rounded-xl p-3 text-xs sm:text-sm text-slate-100 placeholder:text-slate-500 outline-none transition-all resize-none"
          />
        </div>

        {/* Quick Hinglish Suggestions Chips */}
        <div className="mt-2.5">
          <p className="text-[11px] font-medium text-slate-400 mb-1.5 flex items-center gap-1">
            <Zap className="w-3 h-3 text-amber-400" />
            <span>1-Tap Hinglish Ideas:</span>
          </p>
          <div className="flex flex-wrap gap-1.5">
            {HINGLISH_SUGGESTIONS.map((sug, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setUserRequest(sug)}
                className="text-[11px] text-left px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 hover:border-amber-500/40 hover:bg-slate-800 text-slate-300 transition-all truncate max-w-full"
              >
                {sug}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Step 3: Studio Parameters & 100% Face Lock */}
      <div className="bg-[#0e111a] border border-amber-500/20 rounded-2xl p-4 sm:p-5 shadow-xl shadow-black/40 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-amber-500/15 border border-amber-500/30 text-amber-400">
              <Sliders className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-bold text-slate-100">
                3. Studio & Face-Lock Settings
              </h2>
              <p className="text-[11px] text-slate-400">Target AI model, lighting, aspect ratio & camera</p>
            </div>
          </div>
        </div>

        {/* Strict 100% Face Lock Toggle */}
        <div className="p-3 bg-gradient-to-r from-amber-500/10 via-amber-600/5 to-transparent border border-amber-500/30 rounded-xl flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-amber-500/20 text-amber-400">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold text-slate-100">100% Face Identity Lock</span>
                <span className="text-[9px] font-extrabold uppercase px-1.5 py-0.2 rounded bg-amber-500 text-black">
                  Active
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                Guarantees zero facial morphing (InstantID / IP-Adapter weight 0.95)
              </p>
            </div>
          </div>

          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={options.keepOriginalFace}
              onChange={(e) => updateOption('keepOriginalFace', e.target.checked)}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-500"></div>
          </label>
        </div>

        {/* Target Platform Selector */}
        <div>
          <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1">
            <Layers className="w-3.5 h-3.5 text-amber-400" />
            <span>Target AI Platform / Engine:</span>
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {[
              { id: 'midjourney', label: 'Midjourney v6.1', badge: 'Popular' },
              { id: 'flux', label: 'Flux.1 Dev', badge: 'Ultra Real' },
              { id: 'sdxl', label: 'SDXL InstantID', badge: 'Face Lock' },
              { id: 'dalle3', label: 'DALL-E 3', badge: 'Creative' }
            ].map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => updateOption('targetPlatform', p.id as TargetPlatform)}
                className={`flex flex-col items-start p-2.5 rounded-xl border text-left transition-all ${
                  options.targetPlatform === p.id
                    ? 'bg-amber-500/15 border-amber-400 text-amber-300 shadow-md shadow-amber-500/10'
                    : 'bg-slate-900/80 border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between w-full">
                  <span className="text-xs font-bold">{p.label}</span>
                  {options.targetPlatform === p.id && <Check className="w-3 h-3 text-amber-400" />}
                </div>
                <span className="text-[10px] text-slate-500 mt-0.5">{p.badge}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Aspect Ratio & Camera Preset Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {/* Aspect Ratio */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1">
              <Maximize2 className="w-3.5 h-3.5 text-amber-400" />
              <span>Aspect Ratio:</span>
            </label>
            <div className="grid grid-cols-4 gap-1.5">
              {[
                { id: '9:16', label: '9:16', desc: 'Reels' },
                { id: '1:1', label: '1:1', desc: 'Square' },
                { id: '4:5', label: '4:5', desc: 'Insta' },
                { id: '16:9', label: '16:9', desc: 'Cinema' }
              ].map((ar) => (
                <button
                  key={ar.id}
                  type="button"
                  onClick={() => updateOption('aspectRatio', ar.id as AspectRatio)}
                  className={`py-2 px-1 rounded-lg border text-center transition-all ${
                    options.aspectRatio === ar.id
                      ? 'bg-amber-500/20 border-amber-400 text-amber-300 font-bold'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <div className="text-xs">{ar.label}</div>
                  <div className="text-[9px] text-slate-500">{ar.desc}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Quality & Camera Preset */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Camera & Quality Preset:</span>
            </label>
            <select
              value={options.quality}
              onChange={(e) => updateOption('quality', e.target.value as QualityPreset)}
              className="w-full bg-slate-900 border border-slate-700/80 rounded-xl p-2.5 text-xs text-slate-200 outline-none focus:border-amber-400"
            >
              <option value="4k">4K Ultra Photorealistic (Sony A7R V)</option>
              <option value="iphone">iPhone 16 Pro Max Portrait Mode</option>
              <option value="portra_400">35mm Kodak Portra 400 Film</option>
              <option value="hasselblad">Hasselblad 100MP Studio Camera</option>
              <option value="cinematic_8k">8K Anamorphic Movie Still</option>
            </select>
          </div>
        </div>

        {/* Lighting & Background Presets Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {/* Lighting */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1">
              <Sun className="w-3.5 h-3.5 text-amber-400" />
              <span>Lighting:</span>
            </label>
            <select
              value={options.lighting}
              onChange={(e) => updateOption('lighting', e.target.value as LightingPreset)}
              className="w-full bg-slate-900 border border-slate-700/80 rounded-xl p-2 text-xs text-slate-200 outline-none focus:border-amber-400"
            >
              <option value="golden_hour">Golden Hour Sunset</option>
              <option value="diffused_softbox">Studio Softbox Key Light</option>
              <option value="cyber_neon">Cyberpunk Dual Neon</option>
              <option value="rembrandt">Dramatic Rembrandt Shadow</option>
              <option value="sunset_rim">Sunset Rim Backlight</option>
              <option value="cinematic_moody">Moody Film Lighting</option>
            </select>
          </div>

          {/* Background */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1">
              <ImageIcon className="w-3.5 h-3.5 text-amber-400" />
              <span>Background:</span>
            </label>
            <select
              value={options.background}
              onChange={(e) => updateOption('background', e.target.value as BackgroundPreset)}
              className="w-full bg-slate-900 border border-slate-700/80 rounded-xl p-2 text-xs text-slate-200 outline-none focus:border-amber-400"
            >
              <option value="luxury_car">Rolls Royce & Luxury Supercar</option>
              <option value="blur_original">Blur Original Background (f/1.4)</option>
              <option value="royal_palace">Opulent Royal Palace</option>
              <option value="cyberpunk_city">Neo-Tokyo Cyber City</option>
              <option value="penthouse_balcony">Dubai Penthouse Balcony</option>
              <option value="minimal_studio">Clean Minimal Studio</option>
              <option value="nature_mountains">Snow Mountains at Sunrise</option>
            </select>
          </div>

          {/* Clothes */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1">
              <Shirt className="w-3.5 h-3.5 text-amber-400" />
              <span>Outfit & Style:</span>
            </label>
            <select
              value={options.clothes}
              onChange={(e) => updateOption('clothes', e.target.value as ClothesPreset)}
              className="w-full bg-slate-900 border border-slate-700/80 rounded-xl p-2 text-xs text-slate-200 outline-none focus:border-amber-400"
            >
              <option value="black_suit">Black Italian Tuxedo Suit</option>
              <option value="royal_sherwani">Regal Silk Sherwani</option>
              <option value="casual_leather">Cafe-Racer Leather Jacket</option>
              <option value="streetwear_hoodie">Luxury Streetwear Hoodie</option>
              <option value="old_money_linen">Old-Money Linen Blazer</option>
              <option value="cyber_tactical">Futuristic Techwear</option>
              <option value="keep_original">Keep Original Clothes</option>
            </select>
          </div>
        </div>

        {/* Generate Button */}
        <button
          id="generate-4k-prompt-btn"
          type="button"
          onClick={onGenerate}
          disabled={isGenerating}
          className="w-full mt-2 py-3.5 px-6 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-extrabold text-sm sm:text-base flex items-center justify-center gap-2 shadow-xl shadow-amber-500/25 transition-all transform active:scale-[0.99] disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
        >
          {isGenerating ? (
            <>
              <div className="w-5 h-5 border-2 border-black border-t-transparent rounded-full animate-spin"></div>
              <span>Processing 4K Face-Locked Studio Photo & Prompt...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-5 h-5 text-black" />
              <span>Generate 4K AI Photo & Prompt (100% Face Lock)</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};
