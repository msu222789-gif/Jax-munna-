import React, { useRef, useState } from 'react';
import { Camera, Upload, Trash2, ShieldCheck, Sparkles, Scan, CheckCircle2 } from 'lucide-react';

interface PhotoUploaderProps {
  photoPreview: string | null;
  onPhotoSelected: (dataUrl: string | null) => void;
  isScanning: boolean;
}

const SAMPLE_AVATARS = [
  {
    id: 'sample_1',
    label: 'Man Portrait',
    url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=500&auto=format&fit=crop&q=80'
  },
  {
    id: 'sample_2',
    label: 'Woman Portrait',
    url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=500&auto=format&fit=crop&q=80'
  },
  {
    id: 'sample_3',
    label: 'Model Pose',
    url: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=500&auto=format&fit=crop&q=80'
  }
];

export const PhotoUploader: React.FC<PhotoUploaderProps> = ({
  photoPreview,
  onPhotoSelected,
  isScanning
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);

  const processFile = (file: File) => {
    if (!file.type.startsWith('image/')) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      if (!result) return;

      // Compress on canvas for fast mobile processing
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const maxDim = 1080;
        let w = img.width;
        let h = img.height;

        if (w > maxDim || h > maxDim) {
          if (w > h) {
            h = Math.round((h * maxDim) / w);
            w = maxDim;
          } else {
            w = Math.round((w * maxDim) / h);
            h = maxDim;
          }
        }

        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, w, h);
          const compressed = canvas.toDataURL('image/jpeg', 0.85);
          onPhotoSelected(compressed);
        } else {
          onPhotoSelected(result);
        }
      };
      img.src = result;
    };
    reader.readAsDataURL(file);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  return (
    <div className="bg-[#0e111a] border border-amber-500/20 rounded-2xl p-4 sm:p-5 shadow-xl shadow-black/40">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-amber-500/15 border border-amber-500/30 text-amber-400">
            <Camera className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm sm:text-base font-bold text-slate-100">
              1. Reference Photo (Face Lock)
            </h2>
            <p className="text-[11px] text-slate-400">Upload your real face photo for 100% identity preservation</p>
          </div>
        </div>

        {photoPreview && (
          <span className="flex items-center gap-1 text-[11px] font-semibold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-full">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Face Locked</span>
          </span>
        )}
      </div>

      {photoPreview ? (
        <div className="relative group rounded-xl overflow-hidden border border-amber-500/40 bg-black/60 aspect-[4/3] sm:aspect-[16/9] max-h-64 flex items-center justify-center">
          <img
            src={photoPreview}
            alt="Reference Face"
            className="w-full h-full object-cover object-center"
          />

          {/* Scanning Animation */}
          {isScanning && (
            <div className="absolute inset-0 bg-amber-500/10 backdrop-blur-[1px] flex flex-col items-center justify-center">
              <div className="w-32 h-32 border-2 border-dashed border-amber-400 rounded-full animate-spin flex items-center justify-center mb-2">
                <Scan className="w-8 h-8 text-amber-400 animate-pulse" />
              </div>
              <span className="text-xs font-bold text-amber-300 bg-black/80 px-3 py-1 rounded-full border border-amber-500/40 shadow-lg">
                Scanning Facial Landmarks 100%...
              </span>
            </div>
          )}

          {/* Overlay Actions */}
          <div className="absolute bottom-2 left-2 right-2 flex items-center justify-between p-2 rounded-lg bg-black/80 backdrop-blur-md border border-white/10 opacity-90 group-hover:opacity-100 transition-opacity">
            <div className="flex items-center gap-1.5 text-xs text-amber-300 font-medium">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Face Anchor Active (IP-Adapter 0.95)</span>
            </div>
            <button
              onClick={() => onPhotoSelected(null)}
              className="p-1.5 rounded-lg bg-red-500/20 hover:bg-red-500/30 text-red-300 border border-red-500/30 transition-colors"
              title="Remove Reference Photo"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>
      ) : (
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setIsDragging(true);
          }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={handleDrop}
          className={`border-2 border-dashed rounded-xl p-5 text-center transition-all ${
            isDragging
              ? 'border-amber-400 bg-amber-500/10'
              : 'border-slate-800 hover:border-amber-500/40 bg-slate-900/40'
          }`}
        >
          {/* Hidden inputs */}
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept="image/*"
            className="hidden"
          />
          <input
            type="file"
            ref={cameraInputRef}
            onChange={handleFileChange}
            accept="image/*"
            capture="user"
            className="hidden"
          />

          <div className="flex flex-col items-center justify-center">
            <div className="w-12 h-12 rounded-full bg-amber-500/10 border border-amber-500/20 flex items-center justify-center mb-3 text-amber-400">
              <Upload className="w-6 h-6" />
            </div>

            <p className="text-sm font-semibold text-slate-200 mb-1">
              Select or Take Your Face Photo
            </p>
            <p className="text-xs text-slate-400 mb-4 max-w-xs">
              Clear front or 3/4 portrait recommended for best photorealistic face lock
            </p>

            <div className="flex flex-wrap items-center justify-center gap-2.5">
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-black text-xs font-bold transition-all shadow-md shadow-amber-500/20"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Upload From Gallery</span>
              </button>

              <button
                type="button"
                onClick={() => cameraInputRef.current?.click()}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700 text-xs font-semibold transition-all"
              >
                <Camera className="w-3.5 h-3.5 text-amber-400" />
                <span>Take Selfie</span>
              </button>
            </div>
          </div>

          {/* Sample Avatars */}
          <div className="mt-4 pt-4 border-t border-slate-800/80">
            <p className="text-[11px] text-slate-500 mb-2">Or try with sample portraits:</p>
            <div className="flex items-center justify-center gap-2">
              {SAMPLE_AVATARS.map((avatar) => (
                <button
                  key={avatar.id}
                  type="button"
                  onClick={() => onPhotoSelected(avatar.url)}
                  className="flex items-center gap-1.5 px-2 py-1 rounded-lg bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 text-[11px] text-slate-300 transition-colors"
                >
                  <img
                    src={avatar.url}
                    alt={avatar.label}
                    className="w-4 h-4 rounded-full object-cover"
                  />
                  <span>{avatar.label}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
