import React, { useState } from 'react';
import { X, History, Trash2, Copy, Check, Sparkles, ExternalLink, Search } from 'lucide-react';
import { PromptHistoryItem, GeneratedPromptData } from '../types';

interface HistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  history: PromptHistoryItem[];
  onSelectPrompt: (item: GeneratedPromptData) => void;
  onClearHistory: () => void;
  onDeleteItem: (id: string) => void;
}

export const HistoryModal: React.FC<HistoryModalProps> = ({
  isOpen,
  onClose,
  history,
  onSelectPrompt,
  onClearHistory,
  onDeleteItem
}) => {
  const [search, setSearch] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  if (!isOpen) return null;

  const filtered = history.filter(
    (item) =>
      item.masterPrompt.toLowerCase().includes(search.toLowerCase()) ||
      item.userRequest.toLowerCase().includes(search.toLowerCase()) ||
      item.options.targetPlatform.toLowerCase().includes(search.toLowerCase())
  );

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
      <div className="relative w-full max-w-2xl bg-[#0e111a] border border-amber-500/30 rounded-2xl p-5 sm:p-6 shadow-2xl shadow-black/80 text-slate-100 max-h-[85vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400">
              <History className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold text-slate-100">
                Prompt History ({history.length})
              </h3>
              <p className="text-xs text-slate-400">Saved offline in your device storage</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {history.length > 0 && (
              <button
                onClick={onClearHistory}
                className="text-xs text-red-400 hover:text-red-300 px-2 py-1 rounded bg-red-500/10 border border-red-500/20 transition-colors"
              >
                Clear All
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1.5 rounded-full bg-slate-800 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Search */}
        {history.length > 0 && (
          <div className="relative mt-3">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search past prompts..."
              className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs text-slate-200 outline-none focus:border-amber-400"
            />
          </div>
        )}

        {/* History List */}
        <div className="flex-1 overflow-y-auto mt-3 space-y-3 pr-1">
          {history.length === 0 ? (
            <div className="text-center py-12 text-slate-500">
              <Sparkles className="w-8 h-8 mx-auto mb-2 text-slate-600" />
              <p className="text-sm font-semibold">No saved prompts yet</p>
              <p className="text-xs mt-1">Generate your first prompt to see it here automatically.</p>
            </div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-8 text-slate-500 text-xs">
              No matching prompts found for "{search}".
            </div>
          ) : (
            filtered.map((item) => (
              <div
                key={item.id}
                className="p-3.5 bg-slate-900/90 border border-slate-800 hover:border-amber-500/40 rounded-xl transition-all space-y-2"
              >
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300">
                      {item.options.targetPlatform.toUpperCase()}
                    </span>
                    <span className="text-[10px] text-slate-400">{item.options.aspectRatio}</span>
                    <span className="text-[10px] text-slate-500">{item.createdAt}</span>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleCopy(item.id, item.masterPrompt)}
                      className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 text-xs flex items-center gap-1"
                      title="Copy Prompt"
                    >
                      {copiedId === item.id ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                    <button
                      onClick={() => {
                        onSelectPrompt(item);
                        onClose();
                      }}
                      className="p-1.5 rounded-lg bg-amber-500/20 text-amber-300 hover:bg-amber-500/30 text-xs"
                      title="Load in Editor"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => onDeleteItem(item.id)}
                      className="p-1.5 rounded-lg bg-red-500/10 text-red-400 hover:bg-red-500/20 text-xs"
                      title="Delete"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <p className="text-xs text-slate-300 line-clamp-3 font-mono">
                  {item.masterPrompt}
                </p>

                {item.userRequest && (
                  <p className="text-[11px] text-amber-400/80 italic line-clamp-1">
                    Request: "{item.userRequest}"
                  </p>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
