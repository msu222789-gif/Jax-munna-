import React from 'react';
import { Smartphone, Download, X, Sparkles } from 'lucide-react';

interface InstallBannerProps {
  isInstallable: boolean;
  isInstalled: boolean;
  onOpenInstallModal: () => void;
  onDismiss: () => void;
  isDismissed: boolean;
}

export const InstallBanner: React.FC<InstallBannerProps> = ({
  isInstallable,
  isInstalled,
  onOpenInstallModal,
  onDismiss,
  isDismissed
}) => {
  if (isInstalled || isDismissed) return null;

  return (
    <div className="bg-gradient-to-r from-amber-500/20 via-amber-600/15 to-transparent border-b border-amber-500/30 px-3 py-2 text-slate-100 flex items-center justify-between text-xs transition-all">
      <div className="flex items-center gap-2 max-w-[80%]">
        <div className="p-1 rounded-md bg-amber-500 text-black font-bold">
          <Smartphone className="w-3.5 h-3.5" />
        </div>
        <p className="truncate">
          <strong className="text-amber-300">Install JAX MUNNA App:</strong> Fast 1-tap mobile experience on Home Screen!
        </p>
      </div>

      <div className="flex items-center gap-2 flex-shrink-0">
        <button
          onClick={onOpenInstallModal}
          className="px-2.5 py-1 rounded-md bg-amber-500 hover:bg-amber-400 text-black font-bold text-[11px] flex items-center gap-1 shadow-sm"
        >
          <Download className="w-3 h-3" />
          <span>Install</span>
        </button>
        <button
          onClick={onDismiss}
          className="p-1 rounded-full text-slate-400 hover:text-white"
          title="Dismiss banner"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
