import React, { useState } from 'react';
import { X, Smartphone, Download, CheckCircle2, Share, PlusSquare, Sparkles, Box, ShieldCheck, Terminal, Cpu } from 'lucide-react';

interface InstallModalProps {
  isOpen: boolean;
  onClose: () => void;
  onTriggerInstall: () => Promise<boolean>;
  isInstallable: boolean;
  isInstalled: boolean;
  isIOS: boolean;
  isAndroid: boolean;
}

export const InstallModal: React.FC<InstallModalProps> = ({
  isOpen,
  onClose,
  onTriggerInstall,
  isInstallable,
  isInstalled,
  isIOS,
  isAndroid
}) => {
  const [activeView, setActiveView] = useState<'install' | 'apk'>('install');

  if (!isOpen) return null;

  const handleInstallClick = async () => {
    if (isInstallable) {
      const installed = await onTriggerInstall();
      if (installed) {
        onClose();
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-lg bg-[#0e111a] border border-amber-500/30 rounded-3xl p-5 sm:p-6 shadow-2xl shadow-amber-500/10 text-slate-100 max-h-[92vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-full bg-slate-800/80 text-slate-400 hover:text-white hover:bg-slate-700"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3.5 mb-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-500/30 to-amber-700/10 border border-amber-500/50 flex items-center justify-center">
            <Smartphone className="w-6 h-6 text-amber-400" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-transparent bg-clip-text bg-gradient-to-r from-amber-200 to-amber-400">
              JAX MUNNA AI PHOTO EDITOR
            </h3>
            <p className="text-xs text-slate-400">Android Mobile & Native App Package</p>
          </div>
        </div>

        {/* View Switcher Tabs */}
        <div className="flex gap-2 p-1 rounded-xl bg-slate-950 border border-slate-800 mb-4">
          <button
            onClick={() => setActiveView('install')}
            className={`flex-1 py-2 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
              activeView === 'install'
                ? 'bg-amber-500 text-black shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>Direct Phone Install</span>
          </button>
          <button
            onClick={() => setActiveView('apk')}
            className={`flex-1 py-2 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
              activeView === 'apk'
                ? 'bg-amber-500 text-black shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Box className="w-3.5 h-3.5" />
            <span>Android APK / AAB Info</span>
          </button>
        </div>

        {activeView === 'install' ? (
          <>
            {/* Features Checklist */}
            <div className="space-y-2 mb-4 p-3.5 bg-slate-900/80 border border-slate-800 rounded-xl text-xs text-slate-300">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-amber-400 flex-shrink-0" />
                <span>Works 100% fullscreen on Android without browser url bars</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-amber-400 flex-shrink-0" />
                <span>Instant 1-tap launch from Phone Home Screen with app icon</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-amber-400 flex-shrink-0" />
                <span>Fast camera upload, 100% Face Lock & 4K Studio processing</span>
              </div>
            </div>

            {/* Action / Instructions depending on state */}
            {isInstalled ? (
              <div className="p-4 bg-emerald-500/15 border border-emerald-500/30 rounded-xl text-center">
                <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
                <p className="text-sm font-semibold text-emerald-300">App Is Already Installed!</p>
                <p className="text-xs text-slate-400 mt-1">You are running JAX MUNNA in full standalone mobile app mode.</p>
              </div>
            ) : isInstallable ? (
              <div>
                <button
                  onClick={handleInstallClick}
                  className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-bold rounded-xl shadow-lg shadow-amber-500/25 transition-all text-sm cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>Tap to Install on Android Home Screen</span>
                </button>
                <p className="text-[11px] text-center text-slate-400 mt-2">
                  Android Chrome / Browser will prompt to add JAX MUNNA as a native app.
                </p>
              </div>
            ) : isIOS ? (
              <div className="space-y-3 p-4 bg-slate-900 border border-slate-800 rounded-xl text-xs">
                <p className="font-semibold text-amber-300">How to Install on iPhone / iPad:</p>
                <div className="flex items-center gap-2.5 text-slate-300">
                  <Share className="w-4 h-4 text-blue-400 flex-shrink-0" />
                  <span>1. Tap Safari <strong>Share</strong> button at bottom</span>
                </div>
                <div className="flex items-center gap-2.5 text-slate-300">
                  <PlusSquare className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                  <span>2. Scroll down & tap <strong>"Add to Home Screen"</strong></span>
                </div>
                <div className="flex items-center gap-2.5 text-slate-300">
                  <Sparkles className="w-4 h-4 text-amber-400 flex-shrink-0" />
                  <span>3. Tap <strong>"Add"</strong> in the top right corner</span>
                </div>
              </div>
            ) : (
              <div className="space-y-3 p-4 bg-slate-900 border border-slate-800 rounded-xl text-xs">
                <p className="font-semibold text-amber-300">Android Chrome Quick Install:</p>
                <div className="flex items-center gap-2.5 text-slate-300">
                  <div className="w-5 h-5 rounded-full bg-slate-800 flex items-center justify-center text-[10px] font-bold text-amber-400">1</div>
                  <span>Open Chrome menu (tap <strong>⋮</strong> in top right)</span>
                </div>
                <div className="flex items-center gap-2.5 text-slate-300">
                  <div className="w-5 h-5 rounded-full bg-slate-800 flex items-center justify-center text-[10px] font-bold text-amber-400">2</div>
                  <span>Tap <strong>"Install app"</strong> or <strong>"Add to Home Screen"</strong></span>
                </div>
              </div>
            )}
          </>
        ) : (
          /* APK & Android Studio Export Info */
          <div className="space-y-3 text-xs">
            <div className="p-3 bg-slate-900/90 border border-slate-800 rounded-xl space-y-2">
              <div className="flex items-center justify-between text-slate-300">
                <span className="font-semibold text-slate-400">Application Name:</span>
                <span className="font-bold text-amber-400">JAX MUNNA AI PHOTO EDITOR</span>
              </div>
              <div className="flex items-center justify-between text-slate-300">
                <span className="font-semibold text-slate-400">Package ID:</span>
                <span className="font-mono text-slate-200">com.jaxmunna.aiphotoeditor</span>
              </div>
              <div className="flex items-center justify-between text-slate-300">
                <span className="font-semibold text-slate-400">Android Engine:</span>
                <span className="text-emerald-400 font-semibold">Capacitor 8 (Native Android)</span>
              </div>
              <div className="flex items-center justify-between text-slate-300">
                <span className="font-semibold text-slate-400">Min Android Version:</span>
                <span className="text-slate-200">Android 8.0 (API 26+) to Android 15</span>
              </div>
            </div>

            <div className="p-3.5 bg-amber-500/10 border border-amber-500/30 rounded-xl space-y-2 text-amber-200">
              <div className="flex items-center gap-2 font-bold text-amber-300 text-xs">
                <Terminal className="w-4 h-4 text-amber-400" />
                <span>Commands to Build APK on Your Computer / Android Studio:</span>
              </div>
              <div className="p-2.5 bg-black/60 rounded-lg font-mono text-[11px] text-amber-300 space-y-1 select-all overflow-x-auto">
                <p className="text-slate-400"># 1. Sync latest build to Android folder</p>
                <p>npm run cap:build</p>
                <p className="text-slate-400 mt-2"># 2. Build Debug APK directly</p>
                <p>npm run build:apk</p>
                <p className="text-slate-400 mt-2"># 3. Build Signed Release APK or AAB</p>
                <p>npm run build:release-apk</p>
                <p>npm run build:release-aab</p>
              </div>
            </div>

            <p className="text-[11px] text-slate-400">
              The project is fully structured with <code className="text-amber-300">/android</code>, <code className="text-amber-300">AndroidManifest.xml</code>, Gradle build files, and synchronized assets ready for Android Studio or Gradle CLI.
            </p>
          </div>
        )}

        <div className="mt-4 pt-4 border-t border-slate-800 text-center">
          <button
            onClick={onClose}
            className="text-xs text-slate-400 hover:text-slate-200 underline underline-offset-4"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

