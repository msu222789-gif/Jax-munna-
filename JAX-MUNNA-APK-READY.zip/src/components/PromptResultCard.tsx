import React, { useState } from 'react';
import {
  Copy,
  Check,
  Download,
  Share2,
  ShieldCheck,
  Sparkles,
  Info,
  Layers,
  Terminal,
  FileText,
  AlertCircle,
  Eye,
  Maximize2,
  X,
  Image as ImageIcon
} from 'lucide-react';
import { GeneratedPromptData } from '../types';

interface PromptResultCardProps {
  data: GeneratedPromptData;
  onReusePrompt: (data: GeneratedPromptData) => void;
}

export const PromptResultCard: React.FC<PromptResultCardProps> = ({ data, onReusePrompt }) => {
  const [activeTab, setActiveTab] = useState<'master' | 'negative' | 'facelock' | 'hindi'>('master');
  const [copiedMaster, setCopiedMaster] = useState(false);
  const [copiedAll, setCopiedAll] = useState(false);
  const [isBeforeAfter, setIsBeforeAfter] = useState(false);
  const [isLightboxOpen, setIsLightboxOpen] = useState(false);

  const handleCopyMaster = () => {
    navigator.clipboard.writeText(data.masterPrompt);
    setCopiedMaster(true);
    setTimeout(() => setCopiedMaster(false), 2000);
  };

  const handleCopyAll = () => {
    const fullText = `=== JAX MUNNA 4K AI PHOTO PROMPT ===\n\n[MASTER PROMPT]:\n${data.masterPrompt}\n\n[NEGATIVE PROMPT]:\n${data.negativePrompt}\n\n[FACE PRESERVATION]:\n${data.facePreservationTokens}\n\n[PLATFORM PARAMETERS]:\n${data.platformParameters}\n\n[GENERATED AT]: ${data.createdAt}`;
    navigator.clipboard.writeText(fullText);
    setCopiedAll(true);
    setTimeout(() => setCopiedAll(false), 2000);
  };

  const handleDownloadTxt = () => {
    const fullText = `=== JAX MUNNA 4K AI PHOTO PROMPT ===\n\n[TARGET PLATFORM]: ${data.options.targetPlatform.toUpperCase()}\n[ASPECT RATIO]: ${data.options.aspectRatio}\n[QUALITY]: ${data.options.quality}\n\n[MASTER PROMPT]:\n${data.masterPrompt}\n\n[NEGATIVE PROMPT]:\n${data.negativePrompt}\n\n[FACE LOCK SPECIFICATION]:\n${data.facePreservationTokens}\n\n[HINDI EXPLANATION]:\n${data.hindiExplanation}\n\nGenerated with JAX MUNNA AI PHOTO EDITOR PWA`;

    const blob = new Blob([fullText], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `jax-munna-prompt-${Date.now()}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleDownloadPhoto = () => {
    if (!data.generatedPhotoUrl) return;
    const a = document.createElement('a');
    a.href = data.generatedPhotoUrl;
    a.download = `jax-munna-4k-portrait-${Date.now()}.jpg`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'JAX MUNNA AI 4K Photo & Prompt',
          text: data.masterPrompt
        });
      } catch (err) {
        handleCopyMaster();
      }
    } else {
      handleCopyMaster();
    }
  };

  const displayImage = isBeforeAfter && data.referencePhotoPreview
    ? data.referencePhotoPreview
    : (data.generatedPhotoUrl || data.referencePhotoPreview);

  return (
    <div id="generated-prompt-result-card" className="bg-[#0e111a] border-2 border-amber-500/30 rounded-2xl p-4 sm:p-5 shadow-2xl shadow-amber-500/10 space-y-4">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-amber-500/20 text-amber-400">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <span>Ready 4K Studio Output</span>
              <span className="text-[10px] uppercase font-extrabold px-2 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-400">
                100% Face Locked
              </span>
            </h3>
            <p className="text-[11px] text-slate-400">Photorealistic Render & Copyable AI Prompts</p>
          </div>
        </div>

        {/* Quick Highlights Tags */}
        <div className="flex flex-wrap items-center gap-1.5">
          {data.promptHighlights.map((tag, idx) => (
            <span
              key={idx}
              className="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-slate-900 border border-slate-700 text-amber-300"
            >
              {tag}
            </span>
          ))}
        </div>
      </div>

      {/* Generated 4K Photo Preview Section */}
      {data.generatedPhotoUrl && (
        <div className="rounded-xl overflow-hidden border border-slate-800 bg-slate-950/60 p-2.5 space-y-2">
          <div className="flex items-center justify-between px-1 text-xs">
            <span className="font-bold text-slate-200 flex items-center gap-1.5">
              <ImageIcon className="w-3.5 h-3.5 text-amber-400" />
              <span>4K Synthesized Studio Photo</span>
            </span>

            <div className="flex items-center gap-1.5">
              {data.referencePhotoPreview && (
                <button
                  id="toggle-before-after-btn"
                  onClick={() => setIsBeforeAfter(!isBeforeAfter)}
                  className={`px-2 py-1 rounded-md text-[11px] font-semibold border transition-all ${
                    isBeforeAfter
                      ? 'bg-amber-500 text-black border-amber-400 font-bold'
                      : 'bg-slate-900 text-slate-300 border-slate-700 hover:text-white'
                  }`}
                >
                  {isBeforeAfter ? 'Viewing Original Face' : 'Compare Original Face'}
                </button>
              )}

              <button
                id="open-photo-lightbox-btn"
                onClick={() => setIsLightboxOpen(true)}
                className="p-1 rounded-md bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 transition-colors"
                title="Full Screen Zoom"
              >
                <Maximize2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Photo Frame Container */}
          <div className="relative rounded-lg overflow-hidden bg-black/40 aspect-[4/5] sm:aspect-[16/10] max-h-72 flex items-center justify-center group">
            {displayImage && (
              <img
                src={displayImage}
                alt="4K Generated AI Studio Portrait"
                className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                referrerPolicy="no-referrer"
              />
            )}

            {/* Overlay Badge */}
            <div className="absolute top-2 left-2 px-2 py-0.5 rounded-md bg-black/75 backdrop-blur-md text-[10px] font-mono font-bold text-amber-300 border border-amber-500/30 flex items-center gap-1">
              <ShieldCheck className="w-3 h-3 text-emerald-400" />
              <span>{isBeforeAfter ? 'Original Reference Face' : '4K AI Identity Anchored'}</span>
            </div>

            {/* Quick Download Overlay Button */}
            <button
              id="download-photo-overlay-btn"
              onClick={handleDownloadPhoto}
              className="absolute bottom-2.5 right-2.5 flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-bold text-xs shadow-lg transition-transform active:scale-95"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Save 4K Photo</span>
            </button>
          </div>
        </div>
      )}

      {/* Tabs */}
      <div className="flex border-b border-slate-800 gap-1 sm:gap-2">
        {[
          { id: 'master', label: 'Master Prompt', icon: Sparkles },
          { id: 'negative', label: 'Negative Prompt', icon: AlertCircle },
          { id: 'facelock', label: 'Face Lock Anchors', icon: ShieldCheck },
          { id: 'hindi', label: 'Hindi Guide', icon: Info }
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              id={`tab-${tab.id}`}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-1.5 py-2 px-2.5 sm:px-3 text-xs font-semibold rounded-t-lg transition-all border-b-2 ${
                activeTab === tab.id
                  ? 'border-amber-400 text-amber-300 bg-amber-500/10'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab Content Box */}
      <div className="bg-slate-950/90 border border-slate-800 rounded-xl p-3.5 sm:p-4 text-xs sm:text-sm text-slate-200 leading-relaxed font-mono relative">
        {activeTab === 'master' && (
          <div>
            <p className="select-all text-slate-100 whitespace-pre-wrap">{data.masterPrompt}</p>
          </div>
        )}

        {activeTab === 'negative' && (
          <div>
            <p className="text-red-300/90 select-all whitespace-pre-wrap">{data.negativePrompt}</p>
            <p className="text-[11px] text-slate-500 mt-2 font-sans">
              Paste this in Midjourney (--no) or SDXL Negative Prompt field to eliminate morphing & cartoon artifacts.
            </p>
          </div>
        )}

        {activeTab === 'facelock' && (
          <div className="space-y-2">
            <div className="p-2.5 bg-amber-500/10 border border-amber-500/30 rounded-lg text-amber-300">
              <span className="font-bold">Face Lock Parameters:</span> {data.facePreservationTokens}
            </div>
            <p className="text-[11px] text-slate-400 font-sans">
              Applies exact eye structure, nose geometry, cheek contour, and natural skin pores anchoring.
            </p>
          </div>
        )}

        {activeTab === 'hindi' && (
          <div className="font-sans text-slate-300 text-xs sm:text-sm leading-normal">
            <p>{data.hindiExplanation}</p>
          </div>
        )}
      </div>

      {/* Action Buttons Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-2 pt-2">
        <div className="flex flex-wrap items-center gap-2">
          {/* 1-Click Copy Master Prompt */}
          <button
            id="copy-master-prompt-btn"
            onClick={handleCopyMaster}
            className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all shadow-md ${
              copiedMaster
                ? 'bg-emerald-500 text-black shadow-emerald-500/20'
                : 'bg-amber-500 hover:bg-amber-400 text-black shadow-amber-500/20'
            }`}
          >
            {copiedMaster ? (
              <>
                <Check className="w-4 h-4" />
                <span>Copied Master Prompt!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" />
                <span>1-Click Copy Master Prompt</span>
              </>
            )}
          </button>

          {/* Copy Full Bundle */}
          <button
            id="copy-full-bundle-btn"
            onClick={handleCopyAll}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 text-xs font-semibold transition-all"
          >
            {copiedAll ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Layers className="w-3.5 h-3.5" />}
            <span>Copy Full Bundle</span>
          </button>
        </div>

        <div className="flex items-center gap-1.5">
          {/* Download TXT */}
          <button
            id="download-prompt-txt-btn"
            onClick={handleDownloadTxt}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 text-xs font-medium transition-all"
            title="Download Prompt as .txt file"
          >
            <Download className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">Download .txt</span>
          </button>

          {/* Share */}
          <button
            id="share-prompt-btn"
            onClick={handleShare}
            className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 transition-all"
            title="Share Prompt"
          >
            <Share2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Lightbox Modal */}
      {isLightboxOpen && data.generatedPhotoUrl && (
        <div className="fixed inset-0 z-50 bg-black/95 flex flex-col items-center justify-center p-4 backdrop-blur-md">
          <div className="absolute top-4 right-4 flex items-center gap-3 z-10">
            <button
              onClick={handleDownloadPhoto}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-amber-500 text-black font-bold text-xs"
            >
              <Download className="w-4 h-4" />
              <span>Download 4K</span>
            </button>
            <button
              onClick={() => setIsLightboxOpen(false)}
              className="p-2 rounded-xl bg-slate-800 text-slate-200 hover:bg-slate-700"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="max-w-4xl max-h-[85vh] overflow-hidden rounded-2xl border border-amber-500/40 shadow-2xl">
            <img
              src={displayImage}
              alt="Full-screen 4K AI Portrait"
              className="w-full h-full object-contain max-h-[85vh]"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>
      )}
    </div>
  );
};

