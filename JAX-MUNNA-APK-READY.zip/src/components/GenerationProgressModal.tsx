import React, { useEffect, useState } from 'react';
import {
  Sparkles,
  ShieldCheck,
  Cpu,
  Palette,
  Camera,
  Loader2,
  AlertCircle,
  RotateCcw,
  X,
  Clock
} from 'lucide-react';

interface GenerationProgressModalProps {
  isOpen: boolean;
  progressPercent: number;
  currentStage: string;
  elapsedSeconds: number;
  estimatedRemainingSeconds: number;
  isStillProcessing: boolean;
  errorMessage: string | null;
  onRetry: () => void;
  onCancel: () => void;
  hasPhoto: boolean;
}

const STAGES = [
  { id: 1, label: 'Face Identity Lock (100%)', icon: ShieldCheck, minPct: 0, maxPct: 30 },
  { id: 2, label: 'Prompt Engine & Hindi Translation', icon: Cpu, minPct: 30, maxPct: 60 },
  { id: 3, label: 'Attire & Atmosphere Lighting', icon: Palette, minPct: 60, maxPct: 85 },
  { id: 4, label: '4K Optical Tone Mapping', icon: Camera, minPct: 85, maxPct: 100 }
];

export const GenerationProgressModal: React.FC<GenerationProgressModalProps> = ({
  isOpen,
  progressPercent,
  currentStage,
  elapsedSeconds,
  estimatedRemainingSeconds,
  isStillProcessing,
  errorMessage,
  onRetry,
  onCancel,
  hasPhoto
}) => {
  if (!isOpen) return null;

  return (
    <div
      id="generation-progress-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-fadeIn"
    >
      <div
        id="generation-progress-modal-card"
        className="w-full max-w-lg bg-[#0d1017] border-2 border-amber-500/40 rounded-3xl p-5 sm:p-7 shadow-2xl shadow-amber-500/15 relative overflow-hidden"
      >
        {/* Ambient Top Glow */}
        <div className="absolute -top-24 -left-24 w-60 h-60 bg-amber-500/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -right-24 w-60 h-60 bg-amber-600/15 rounded-full blur-3xl pointer-events-none" />

        {/* Top Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800 relative z-10">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
              {errorMessage ? (
                <AlertCircle className="w-5 h-5 text-rose-400" />
              ) : (
                <Sparkles className="w-5 h-5 animate-pulse" />
              )}
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-slate-100 flex items-center gap-2">
                <span>{errorMessage ? 'Generation Encountered An Issue' : 'Generating 4K AI Photo & Prompt'}</span>
              </h2>
              <p className="text-xs text-slate-400">
                {errorMessage
                  ? 'Please review error below and retry'
                  : 'Synthesizing 100% Face Locked photo & high-precision prompt'}
              </p>
            </div>
          </div>

          {!errorMessage && (
            <button
              id="cancel-generation-btn"
              onClick={onCancel}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
              title="Cancel Generation"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Modal Body */}
        <div className="py-5 space-y-5 relative z-10">
          {errorMessage ? (
            /* Error View with Retry */
            <div className="p-4 rounded-2xl bg-rose-950/40 border border-rose-500/40 text-rose-200 space-y-3">
              <div className="flex items-center gap-2 text-rose-300 font-bold text-sm">
                <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
                <span>Generation Paused</span>
              </div>
              <p className="text-xs text-rose-200/90 leading-relaxed font-sans">{errorMessage}</p>
              <div className="flex items-center gap-2 pt-2">
                <button
                  id="retry-generation-btn"
                  onClick={onRetry}
                  className="flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-bold text-xs sm:text-sm shadow-lg shadow-amber-500/25 transition-all"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>Retry Generation</span>
                </button>
                <button
                  onClick={onCancel}
                  className="py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors"
                >
                  Close
                </button>
              </div>
            </div>
          ) : (
            /* Normal Processing State */
            <>
              {/* Progress Bar & Percentage */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs sm:text-sm">
                  <span className="font-bold text-amber-300 flex items-center gap-1.5">
                    <Loader2 className="w-4 h-4 animate-spin text-amber-400" />
                    <span>{currentStage || 'Processing neural layers...'}</span>
                  </span>
                  <span className="font-mono font-extrabold text-amber-400 text-base">
                    {Math.min(Math.max(Math.round(progressPercent), 1), 99)}%
                  </span>
                </div>

                {/* Outer Track */}
                <div className="w-full h-3.5 bg-slate-950 rounded-full border border-slate-800 overflow-hidden p-0.5 shadow-inner">
                  <div
                    className="h-full bg-gradient-to-r from-amber-600 via-amber-400 to-amber-300 rounded-full transition-all duration-300 ease-out relative"
                    style={{ width: `${Math.min(Math.max(progressPercent, 5), 99)}%` }}
                  >
                    <div className="absolute inset-0 bg-white/20 animate-pulse rounded-full" />
                  </div>
                </div>
              </div>

              {/* Estimated Time Badge */}
              <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs">
                <div className="flex items-center gap-2 text-slate-300">
                  <Clock className="w-4 h-4 text-amber-400" />
                  <span>
                    Estimated remaining:{' '}
                    <strong className="text-amber-300">
                      {estimatedRemainingSeconds > 0 ? `~${estimatedRemainingSeconds} seconds` : 'Finishing touches...'}
                    </strong>
                  </span>
                </div>
                <span className="text-[11px] font-mono text-slate-400">Elapsed: {elapsedSeconds}s</span>
              </div>

              {/* Still Processing Notification if slow */}
              {isStillProcessing && (
                <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs flex items-center gap-2 animate-pulse">
                  <Loader2 className="w-4 h-4 animate-spin shrink-0 text-amber-400" />
                  <span>Still processing... Refining ultra-fine textures & lighting. Your photo is almost ready!</span>
                </div>
              )}

              {/* Sequential Processing Steps Checklist */}
              <div className="space-y-2 pt-1">
                <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                  Pipeline Processing Steps:
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {STAGES.map((stage) => {
                    const Icon = stage.icon;
                    const isCompleted = progressPercent >= stage.maxPct;
                    const isCurrent = progressPercent >= stage.minPct && progressPercent < stage.maxPct;

                    return (
                      <div
                        key={stage.id}
                        className={`p-2.5 rounded-xl border flex items-center gap-2.5 transition-all text-xs ${
                          isCompleted
                            ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                            : isCurrent
                            ? 'bg-amber-500/15 border-amber-500/50 text-amber-200 ring-1 ring-amber-400/40 shadow-sm'
                            : 'bg-slate-900/40 border-slate-800/80 text-slate-500'
                        }`}
                      >
                        <div
                          className={`w-6 h-6 rounded-lg flex items-center justify-center shrink-0 ${
                            isCompleted
                              ? 'bg-emerald-500/20 text-emerald-400'
                              : isCurrent
                              ? 'bg-amber-500/20 text-amber-400'
                              : 'bg-slate-800 text-slate-500'
                          }`}
                        >
                          <Icon className="w-3.5 h-3.5" />
                        </div>
                        <span className="font-medium text-[11px] leading-tight truncate">{stage.label}</span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Face Lock Guarantee Pill */}
              <div className="flex items-center justify-center gap-2 text-center text-[11px] text-slate-400 pt-1">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>
                  {hasPhoto
                    ? 'Uploaded face geometry anchored with 100% precision'
                    : 'Aesthetic reference face template enabled with 4K clarity'}
                </span>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
