import{W as n}from"./index-DFySAA8H.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
