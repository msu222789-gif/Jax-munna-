package com.jaxmunna.aiphotoeditor;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
